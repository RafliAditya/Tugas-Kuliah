package penjualan;
import java.util.Scanner;
public class penjualan  {

    public static void main(String[] args) {
    Scanner scan = new Scanner (System.in);
    
  String nama_barang1;
  String nama_barang2;
  String nama_barang3;
  String nama_barang;
  
  int jenis_barang;
  int jml_barang, jml_barang1, jml_barang2, jml_barang3;
  int harga_satuan, harga_satuan1, harga_satuan2, harga_satuan3;
  int subtotal1, subtotal2, subtotal3;
  int total_harga, total_bayar;
  
  System.out.println("\nPENJUALAN ALAT TULIS");
  System.out.println();
  
  System.out.print("Masukan Jumlah Jenis Barang = ");
  jenis_barang = scan.nextInt();
  
  if(jenis_barang>=1 && jenis_barang<2) {
  System.out.print("Nama Barang  : ");
  nama_barang = scan.next();
  System.out.print("Stok  : ");
  jml_barang = scan.nextInt();
  System.out.print("Harga Satuan  : ");
  harga_satuan = scan.nextInt();
  
  total_harga = harga_satuan * jml_barang;
  total_bayar = (total_harga);
  
  
  if(total_harga>=500000){
  }else if (total_harga>=0 && total_harga<500000){
   System.out.println("\nTotal Bayar : "+total_harga+"");
   
  }
  }
  
  else if (jenis_barang>=3 && jenis_barang<4) {
  System.out.println("\nBarang ke-1 \n");
  System.out.print("Nama Alat Tulis  : ");
  nama_barang1 = scan.next();
  System.out.print("Stok   : ");
  jml_barang1 = scan.nextInt();
  System.out.print("Harga Satuan  : ");
  harga_satuan1 = scan.nextInt();
  subtotal1 = harga_satuan1 * jml_barang1;
  System.out.println("Subtotal  : "+subtotal1);

  System.out.println("\nBarang ke-2 \n");
  System.out.print("Nama Alat Tulis  : ");
  nama_barang2 = scan.next();
  System.out.print("Stok  : ");
  jml_barang2 = scan.nextInt();
  System.out.print("Harga Satuan  : ");
  harga_satuan2 = scan.nextInt();
  subtotal2 = harga_satuan2 * jml_barang2; 
  System.out.println("Subtotal  : "+subtotal2);
  
  System.out.println("\nBarang ke-3 \n");
  System.out.print("Nama Alat Tulis  : ");
  nama_barang3 = scan.next();
  System.out.print("Stok  : ");
  jml_barang3 = scan.nextInt();
  System.out.print("Harga Satuan  : ");
  harga_satuan3 = scan.nextInt();
  subtotal3 = harga_satuan2 * jml_barang2; 
  System.out.println("Subtotal  : "+subtotal2);
  
  total_harga = subtotal1 + subtotal2 + subtotal3;
   
  if(total_harga>=500000){
   System.out.println();
  }else if (total_harga>=0 && total_harga<500000){
   System.out.println("\nTotal Bayar : "+total_harga+"");
   System.out.println();
   
  }
  }
    }
    }
  
 
     
  
    


